---
author: David Grisham
title: Quantum Operator Libs -- Quick Start Guide
...

**Refer to 'main.py' for the example that this introduction discusses**

Overview
========

in this example, we create a 3 qubit system and operate on the last two qubits
with the pauli X ('not') operator.

Initial Condition (IC)
----------------------

the IC is a string that is processed by state.py to create the states that we
wish to use. we can create any state we want with this code, but we'll just
look at the form 'qt<theta>_p<phi>', where theta and phi are numbers in
degrees (see the next text block for more info). note that an initial
condition in this form puts *all* of the qubits in our system in the initial
state specified by IC

the IC, 'qt90_p0', is mostly specified by the 't90' and 'p0' parts.
the 't' means 'theta', and 'p' means 'phi'. these theta and phi values
specify the angles of our state within the Bloch sphere. so the values
theta=90(degrees) and phi=0(degrees) put each of our qubits in an equal
superposition state: 1/sqrt(2) * (|0> + |1>).

Everything else
---------------

now that we understand how to parse the IC string in this example, let's look
at the rest of the values that we have to specify. the first is L, which is
the number of qubits in our system. OPs is a list of operators that we wish to
apply to the qubits. however, the number of OPs does not have to be equal to
the number of qubits.

### OPs

in this example, the OPs list has two operators in it: pauli X and pauli Y.
this is because we want to operate X on one qubit, and Y on another. note that
we have 3 qubits but only 2 operators -- the qubit that we don't operate on
technically has an Identity applied to it, but the Identity doesn't actually
do anything to our state and thus we omit it here (this is only possible as a
result of the algorithm used to operate on our state)

### js

the final piece is our 'js' list. this is a list of the qubits that we wish to
apply our operators to. in this example, we wish to operate pauli X on qubit
1, and pauli Y on qubit 2 (qubits are indexed from 0, so 1 and 2 correspond to
the second and third qubits in our system, resp.). note that the order of the
qubit indices specified in 'js' corresponds to the order of the OPs. the
following example may help clarify further:

assume we have a 100 qubit system, and we want to apply the pauli X operator
to qubits 2 and 3, and the pauli Y operator to qubit 10. then our OPs and 'js'
lists might look like:

- OPs = [pauli['X'], pauli['X'], pauli['Y']]
- js = [2, 3, 10]

these could be equivalently written as:

- OPs = [pauli['X'], pauli['Y'], pauli['X']]
- js = [2, 10, 3]

or even:

- OPs = [pauli['Y'], pauli['X'], pauli['X']]
- js = [10, 3, 2]

basically, the relative ordering of OPs and js is all that matters here

